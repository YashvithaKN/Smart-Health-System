# smart_health_project/data/seed_data.py
import os
import django
import csv
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
# project root is parent of data
PROJECT_ROOT = BASE_DIR.parent
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smart_health_project.settings')
import sys
sys.path.append(str(PROJECT_ROOT))
django.setup()

from nutrition.models import Food

def run():
    csv_path = PROJECT_ROOT / 'data' / 'foods.csv'
    print("Seeding from:", csv_path)
    if not csv_path.exists():
        print("ERROR: foods.csv not found at", csv_path)
        return

    with open(csv_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        added = 0
        for row in reader:
            # convert numeric fields safely
            try:
                defaults = {
                    'calories': float(row.get('calories', 0) or 0),
                    'protein': float(row.get('protein', 0) or 0),
                    'fat': float(row.get('fat', 0) or 0),
                    'carbs': float(row.get('carbs', 0) or 0),
                    'fiber': float(row.get('fiber', 0) or 0),
                }
            except ValueError:
                defaults = {'calories':0,'protein':0,'fat':0,'carbs':0,'fiber':0}
            obj, created = Food.objects.get_or_create(name=row['name'], defaults=defaults)
            if created:
                added += 1
        print(f"Seed complete. {added} items added.")

if __name__ == '__main__':
    run()
