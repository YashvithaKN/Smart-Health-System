from django.http import JsonResponse, HttpResponse
from mealplanner.models import MealPlan
from django.contrib.auth.decorators import login_required


def api_home(request):
    """Simple welcome message for API root endpoint."""
    return HttpResponse("Welcome to the SmartHealth API Home! Use /api/mealplans/ to fetch your meal plans.")


@login_required
def user_mealplans(request):
    """Return JSON of the logged-in user's meal plans."""
    plans = MealPlan.objects.filter(user=request.user)
    data = []
    for plan in plans:
        data.append({
            'goal': plan.goal,
            'calories': plan.total_calories,
            'breakfast': plan.breakfast,
            'lunch': plan.lunch,
            'dinner': plan.dinner,
            'date_created': plan.date_created.strftime('%Y-%m-%d')
        })
    return JsonResponse({'mealplans': data})
