from django.apps import AppConfig


class MealplannerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mealplanner'
