from django.db import models
from django.contrib.auth.models import User


class Recipe(models.Model):
    name = models.CharField(max_length=100)
    # Allow empty ingredients for existing data or provide a default
    ingredients = models.TextField(blank=True, null=True, default="Not specified")
    instructions = models.TextField(blank=True, null=True)
    calories = models.FloatField(default=0.0)
    image_url = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.name


class MealPlan(models.Model):
    # Use AUTH_USER_MODEL for compatibility with custom user models
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date_created = models.DateTimeField(auto_now_add=True)
    goal = models.CharField(max_length=50, choices=[
        ('weight_loss', 'Weight Loss'),
        ('muscle_gain', 'Muscle Gain'),
        ('maintenance', 'Maintenance'),
    ])
    total_calories = models.FloatField(default=0.0)
    breakfast = models.TextField(blank=True, null=True)
    lunch = models.TextField(blank=True, null=True)
    dinner = models.TextField(blank=True, null=True)
    

    def __str__(self):
        return f"{self.user.username}'s Meal Plan - {self.goal}"
