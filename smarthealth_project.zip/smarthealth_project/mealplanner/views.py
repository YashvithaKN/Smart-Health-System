from django.shortcuts import render, get_object_or_404
from .models import MealPlan
from django.contrib.auth.decorators import login_required

@login_required
def planner(request):
    plans = MealPlan.objects.filter(user=request.user).order_by('-date_created')
    return render(request, 'mealplanner/planner.html', {'plans': plans})

@login_required
def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    return render(request, 'mealplanner/recipe_detail.html', {'recipe': recipe})
