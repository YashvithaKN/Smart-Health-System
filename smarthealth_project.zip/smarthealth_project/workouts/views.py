# workouts/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .ml_logic import recommend_workouts_from_profile


@login_required
def recommend(request):
    """
    Show AI (rule-based) recommended workouts based on the logged-in user's profile.
    """
    user = request.user

    # Safely try to obtain profile fields.
    # Common patterns:
    #   - user.profile (one-to-one)
    #   - accounts.models.Profile with OneToOne relation
    # We'll try attribute access and dictionary fallback.
    profile_obj = getattr(user, "profile", None)

    # gather available profile info
    profile_data = {}
    # common names used in many projects; adjust if your profile uses other field names
    if profile_obj is not None:
        # use getattr with default None to avoid AttributeError
        profile_data["age"] = getattr(profile_obj, "age", None)
        profile_data["gender"] = getattr(profile_obj, "gender", None)
        # height in cm / weight in kg are expected; adjust names if different
        profile_data["height_cm"] = getattr(profile_obj, "height_cm", None) or getattr(profile_obj, "height", None)
        profile_data["weight_kg"] = getattr(profile_obj, "weight_kg", None) or getattr(profile_obj, "weight", None)
        profile_data["fitness_goal"] = getattr(profile_obj, "fitness_goal", None) or getattr(profile_obj, "goal", None)
    else:
        # fallback: attempt to find fields on user model (very unlikely)
        profile_data["age"] = getattr(user, "age", None)
        profile_data["gender"] = getattr(user, "gender", None)
        profile_data["height_cm"] = getattr(user, "height_cm", None)
        profile_data["weight_kg"] = getattr(user, "weight_kg", None)
        profile_data["fitness_goal"] = getattr(user, "fitness_goal", None)

    # If absolutely no useful data, still run recommender with empty profile (will return generic)
    results = recommend_workouts_from_profile(profile_data)

    context = {
        "workouts": results["workouts"],
        "bmi": results["bmi"],
        "reason": results["reason"],
        "profile_data": profile_data,
    }

    return render(request, "workouts/recommend.html", context)
