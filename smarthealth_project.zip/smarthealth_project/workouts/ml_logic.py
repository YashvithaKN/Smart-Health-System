from typing import Dict, List, Optional


def compute_bmi(weight_kg: Optional[float], height_cm: Optional[float]) -> Optional[float]:
    """Return BMI rounded to 1 decimal, or None if not computable."""
    try:
        if weight_kg is None or height_cm is None:
            return None
        h_m = height_cm / 100.0
        if h_m <= 0:
            return None
        bmi = weight_kg / (h_m * h_m)
        return round(bmi, 1)
    except Exception:
        return None


def normalize_goal(goal: Optional[str]) -> str:
    if not goal:
        return ""
    return goal.strip().lower()


def recommend_workouts_from_profile(profile: Dict) -> Dict:
    """
    profile: dict with keys maybe including:
      - age (int)
      - gender (str)
      - height_cm (float)
      - weight_kg (float)
      - fitness_goal (str)
    Returns:
      { 'bmi': float|None, 'reason': str, 'workouts': [str, ...] }
    """
    age = profile.get("age")
    gender = profile.get("gender")
    height_cm = profile.get("height_cm")
    weight_kg = profile.get("weight_kg")
    goal = normalize_goal(profile.get("fitness_goal"))

    bmi = compute_bmi(weight_kg, height_cm)

    # base buckets
    workouts: List[str] = []
    reason_parts: List[str] = []

    # Safety / low-impact priority
    low_impact = False
    if (isinstance(age, (int, float)) and age >= 60) or (bmi is not None and bmi >= 30):
        low_impact = True
        reason_parts.append("low-impact recommended due to age/BMI")

    # Undernourished / underweight
    underweight = False
    if bmi is not None and bmi < 18.5:
        underweight = True
        reason_parts.append("underweight — focus on light strength + nutrition advice")

    # Choose by declared fitness goal
    if "lose" in goal or "fat" in goal or "weight loss" in goal:
        if low_impact:
            workouts += ["Brisk Walking (30–45 min)", "Swimming (low-impact cardio)", "Elliptical / Stationary Bike", "Gentle Yoga (for mobility)", "Light Strength (bodyweight squats)"]
        else:
            workouts += ["HIIT (20–30 min)", "Running / Jogging (intervals)", "Cycling (outdoor or stationary)", "Circuit Training", "Jump Rope (short intervals)"]
        reason_parts.append("goal: fat loss / cardio emphasis")
    elif "gain" in goal or "muscle" in goal or "bulk" in goal:
        workouts += ["Full-Body Strength (compound lifts)", "Squats (bodyweight -> weighted)", "Push-ups / Bench variations", "Deadlifts / Hip hinges", "Progressive Overload Program"]
        reason_parts.append("goal: muscle / strength building")
    elif "stamina" in goal or "endurance" in goal or "cardio" in goal:
        workouts += ["Long Run / Tempo Run", "Cycling (endurance rides)", "Swimming (continuous)", "Rowing", "Steady-state Cardio"]
        reason_parts.append("goal: stamina / endurance")
    elif "flexibility" in goal or "yoga" in goal or "mobility" in goal:
        workouts += ["Hatha Yoga", "Vinyasa Flow", "Dynamic Stretching", "Pilates", "Mobility Drills"]
        reason_parts.append("goal: flexibility / mobility")
    else:
        # Generic balanced program
        workouts += ["Full-Body Strength (2–3x wk)", "Cardio (20–30 min, 2–3x wk)", "Mobility/Yoga (2x wk)", "Core Stability (planks, dead bugs)", "Active Recovery (walking)"]
        reason_parts.append("goal: general fitness ")

    # Add adjustments for underweight
    if underweight:
        # prefer strength and calorie-focused exercises (but gentle)
        extra = ["Light Resistance Training (focus on progressive overload)", "Calorie-rich nutrition guidance (not a workout)"]
        # place nutrition note at end
        workouts = workouts[:3] + extra + workouts[3:]

    # Trim / dedupe and ensure 5 recommendations (try to diversify)
    seen = set()
    final = []
    for w in workouts:
        if w not in seen:
            final.append(w)
            seen.add(w)
        if len(final) >= 5:
            break

    # If low-impact only 5 already; else try to fill if less than 5
    if len(final) < 5:
        fallback = ["Brisk Walking", "Stretching Routine", "Bodyweight Circuit", "Short HIIT", "Yoga"]
        for f in fallback:
            if f not in seen:
                final.append(f)
            if len(final) >= 5:
                break

    # Compose reason
    reason = "; ".join(reason_parts) if reason_parts else "Recommendation based on profile data."

    return {"bmi": bmi, "reason": reason, "workouts": final}
