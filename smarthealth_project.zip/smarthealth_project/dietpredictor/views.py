from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from mealplanner.models import MealPlan
import random

@login_required
def predict(request):
    """Simple mock-up ML diet prediction."""
    profile = request.user.profile

    bmi = 0
    if profile.height and profile.weight:
        h = profile.height / 100
        bmi = profile.weight / (h * h)

    # Simple ML-like logic
    if bmi < 18.5:
        goal = "muscle_gain"
        calories = random.randint(2500, 2800)
    elif 18.5 <= bmi <= 24.9:
        goal = "maintenance"
        calories = random.randint(2000, 2200)
    else:
        goal = "Nurture"
        calories = random.randint(1500, 1800)

    # Example foods (you can make this dynamic from dataset)
    breakfast = random.choice(["Oats with milk", "Smoothie bowl", "Scrambled eggs"])
    lunch = random.choice(["Grilled chicken & rice", "Quinoa salad", "Paneer wrap"])
    dinner = random.choice(["Soup & salad", "Grilled fish", "Vegetable curry"])

    # Save plan
    if request.method == "POST":
        plan = MealPlan.objects.create(
            user=request.user,
            goal=goal,
            total_calories=calories,
            breakfast=breakfast,
            lunch=lunch,
            dinner=dinner
        )
        plan.save()
        return redirect('mealplanner:planner')

    context = {
        'goal': goal,
        'calories': calories,
        'bmi': round(bmi, 1),
        'breakfast': breakfast,
        'lunch': lunch,
        'dinner': dinner,
    }
    return render(request, 'dietpredictor/predict.html', context)
