from django.apps import AppConfig


class DietpredictorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dietpredictor'
