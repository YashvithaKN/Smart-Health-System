from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

# Load FAQ once
with open('chatbot/data/faq.json', 'r') as f:
    FAQ_DATA = json.load(f)

@csrf_exempt
def chat(request):
    """Simple FAQ-based chatbot"""
    if request.method == "POST":
        user_msg = request.POST.get('message', '').lower()
        response = "Sorry, I don't understand your question."

        for faq in FAQ_DATA:
            if faq['question'].lower() in user_msg:
                response = faq['answer']
                break

        return JsonResponse({'reply': response})

    return render(request, 'chatbot/chat.html')
