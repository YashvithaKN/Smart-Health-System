import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from django.conf import settings
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE_DIR / 'ml' / 'models'
MODEL_DIR.mkdir(parents=True, exist_ok=True)

FOODS_CSV = BASE_DIR / 'data' / 'foods.csv'

def load_foods_df():
    if not FOODS_CSV.exists():
        raise FileNotFoundError(f"{FOODS_CSV} not found")
    df = pd.read_csv(FOODS_CSV)
    return df

def train_low_protein_model():
    df = load_foods_df()
    features = ['protein','fat','carbs','calories']
    df = df.dropna(subset=features)
    X = df[features].values
    y = (df['protein'] < 5).astype(int).values
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(Xs, y, test_size=0.2, random_state=42)
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_train, y_train)
    acc = clf.score(X_test, y_test)
    joblib.dump(clf, MODEL_DIR / 'low_protein_model.joblib')
    joblib.dump(scaler, MODEL_DIR / 'scaler.joblib')
    print("Trained low_protein_model (accuracy:", acc, ")")
    return acc

def load_model(name):
    path = MODEL_DIR / name
    if not path.exists():
        raise FileNotFoundError(path)
    return joblib.load(path)

def predict_low_protein_from_row(row):
    scaler = load_model('scaler.joblib')
    model = load_model('low_protein_model.joblib')
    X = [[row['protein'], row['fat'], row['carbs'], row['calories']]]
    Xs = scaler.transform(X)
    prob = model.predict_proba(Xs)[0][1]
    return prob
