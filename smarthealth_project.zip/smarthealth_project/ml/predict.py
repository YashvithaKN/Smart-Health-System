import pandas as pd
import joblib
import numpy as np
import os
from sklearn.metrics.pairwise import cosine_similarity
from django.conf import settings
from nutrition.models import Food
from pathlib import Path


BASE = Path(__file__).resolve().parent
MODEL_DIR = os.path.join(settings.BASE_DIR, 'ml', 'models')
foods = joblib.load(MODEL_DIR / 'foods.pkl')
nn = joblib.load(MODEL_DIR / 'nn_food.joblib')
clf = joblib.load(MODEL_DIR / 'deficiency_clf.joblib')




def predict_low_protein(food_id):
    food = Food.objects.get(pk=food_id)
    model_path = os.path.join(MODEL_DIR, 'low_protein_model.joblib')
    model = joblib.load(model_path)
    features = [[food.protein, food.fat, food.carbs, food.calories]]
    prob = model.predict_proba(features)[0][1]  # Probability of being "low protein"
    return round(prob * 100, 2)


# Example: Content-based recommendation using cosine similarity
def recommend_similar(food_id, n=5):
    df = pd.read_csv(os.path.join(settings.BASE_DIR, 'data', 'foods.csv'))
    if 'id' not in df.columns:
        df['id'] = range(1, len(df) + 1)

    food = df[df['id'] == food_id].iloc[0]
    features = df[['calories', 'protein', 'fat', 'carbs']].values
    similarity = cosine_similarity([features[food_id - 1]], features)
    top_indices = similarity[0].argsort()[-n-1:][::-1][1:]

    recs = df.iloc[top_indices][['name', 'calories', 'protein', 'fat', 'carbs']].to_dict('records')
    return recs