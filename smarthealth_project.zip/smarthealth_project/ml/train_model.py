import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import joblib
from pathlib import Path


BASE = Path(__file__).resolve().parent
DATA = BASE.parent / 'data' / 'foods.csv'
MODEL_DIR = BASE / 'models'
MODEL_DIR.mkdir(exist_ok=True)


# 1) Train KMeans on users (here: use seed synthetic or real user features if available)
# For demo: we only train food recommender and a simple deficiency predictor.


foods = pd.read_csv(DATA)
# expect columns: name, calories, protein, carbs, fat, fiber, sodium
nutrient_cols = ['calories','protein','carbs','fat','fiber']
X = foods[nutrient_cols].fillna(0).values


# NearestNeighbors recommender (food similarity)
nn = NearestNeighbors(n_neighbors=10, metric='euclidean')
nn.fit(X)
joblib.dump(nn, MODEL_DIR / 'nn_food.joblib')


# Also save foods dataframe for lookup
foods.to_pickle(MODEL_DIR / 'foods.pkl')


# Example deficiency predictor (synthetic training)
# create a synthetic target: low_protein if protein < 10g
foods['low_protein'] = (foods['protein'] < 10).astype(int)
clf = LogisticRegression(max_iter=200)
clf.fit(X, foods['low_protein'])
joblib.dump(clf, MODEL_DIR / 'deficiency_clf.joblib')


print('Models trained and saved to', MODEL_DIR)