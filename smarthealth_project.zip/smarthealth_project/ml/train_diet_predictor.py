import pickle
from sklearn.ensemble import RandomForestClassifier
from ml.utils import load_diet_data

# Load data
X, y, le_goal = load_diet_data()

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# Save model
with open('ml/diet_predictor_model.pkl', 'wb') as f:
    pickle.dump({'model': model, 'label_encoder': le_goal}, f)

print("Diet Predictor Model trained and saved successfully!")
