from django.urls import path
from . import views

urlpatterns = [
    # Example route
    path('', views.index, name='ml_index'),
]
