from django.http import HttpResponse

def index(request):
    return HttpResponse("ML app is working!")
