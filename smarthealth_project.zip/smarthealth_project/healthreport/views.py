from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def report(request):
    """
    Displays user health report including BMI, recent diet, and progress charts.
    """
    profile = request.user.profile
    bmi = None
    if profile.height and profile.weight:
        height_m = profile.height / 100
        bmi = round(profile.weight / (height_m ** 2), 1)

    # Example historical BMI data for chart
    bmi_history = {
        'dates': ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        'values': [22.5, 22.1, 21.9, 21.8, bmi or 22.0]
    }

    context = {
        'profile': profile,
        'bmi': bmi,
        'bmi_history': bmi_history
    }
    return render(request, 'healthreport/report.html', context)
