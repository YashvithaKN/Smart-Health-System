from django.urls import path
from . import views

app_name = 'healthreport'

urlpatterns = [
    path('', views.report, name='report'),
]
