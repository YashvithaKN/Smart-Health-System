from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def plan(request):
    """
    Shows personalized weekly health plan for the user including diet, exercise, and tips.
    """
    profile = request.user.profile
    weekly_plan = [
        {'day': 'Monday', 'exercise': 'Jogging 30 min', 'diet': 'High protein diet'},
        {'day': 'Tuesday', 'exercise': 'Yoga 20 min', 'diet': 'Balanced diet'},
        {'day': 'Wednesday', 'exercise': 'Strength training', 'diet': 'Low carb diet'},
        {'day': 'Thursday', 'exercise': 'Swimming', 'diet': 'Vegetarian diet'},
        {'day': 'Friday', 'exercise': 'Cycling', 'diet': 'High protein diet'},
        {'day': 'Saturday', 'exercise': 'Rest', 'diet': 'Light diet'},
        {'day': 'Sunday', 'exercise': 'Walk', 'diet': 'Balanced diet'}
    ]
    return render(request, 'healthplan/plan.html', {'weekly_plan': weekly_plan})
