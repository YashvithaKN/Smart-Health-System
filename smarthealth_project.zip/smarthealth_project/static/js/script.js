document.addEventListener("DOMContentLoaded", function () {
    console.log("Smart Health System Dashboard loaded successfully.");
});
